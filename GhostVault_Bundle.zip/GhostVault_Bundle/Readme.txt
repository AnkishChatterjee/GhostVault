🛡️ GhostVault Secure v1.0
GhostVault is a high-security file encryption utility designed to protect your sensitive data using dual-layer RSA/AES encryption.

🚀 How to Use
First Run: When you open the app for the first time, set a Master Password. This password creates your unique digital identity.

Securing Files: Right-click any file on your computer and select "Secure with GhostVault". The original file will be deleted and replaced with a protected .ghost version.

Restoring Files: Open the GhostVault app, click "Restore File", and select your .ghost file. Enter your password to decrypt it.

🔑 Security Features
10-Minute Session: Once you enter your password, the vault stays "unlocked" for 10 minutes so you can restore multiple files without re-typing your password.

Panic Button: If you need to lock everything instantly, click the Red Panic Button or press the ESC key. This wipes your password from the computer's memory and shuts down the app.

Dual-Key Protection: Your files are protected by your password and a developer-level Master Key for emergency recovery.

⚠️ Important Warnings
Do Not Delete PEM Files: GhostVault creates two files (local_private.pem and local_public.pem) in its folder. If you delete these, you will lose access to your files.

Password Recovery: If you forget your password, you cannot recover your files alone. You must contact the developer (info below) to use the Master Recovery Key.

🛠️ Support & Recovery
If you encounter issues or need a Master Key recovery, please contact:

Developer: [Your Name/Company]

Email: [Your Email Address]

Website: [Your Website Link]